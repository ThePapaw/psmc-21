GUI Sounds for the PSMC's Scooby-Doo skin.
